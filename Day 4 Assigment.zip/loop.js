
 for (let i = 0; i<= 100; i++ ){
     if(i%3 == 0){
         console.log("fizz");
         if(i%5 == 0){
             console.log("buzz");
             console.log("fizzbuzz");
         }
     }
     else if(i%5 == 0){
         console.log("buzz");
     }
     else{
         continue;
     }
 }