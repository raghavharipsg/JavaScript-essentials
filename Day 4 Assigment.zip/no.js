var sa = prompt("Entert the number:");
console.log(sa);
for (let i = 0; i > -1; i++) {
   let va = sa > 100 ? "yes" : "no";
    if (va == 'yes') {
        console.log("You have succesfully enteredd a number " +sa);
        break;
    }
    else{
        console.log("You have  entered a wrong value");
        var sa = 0;
        sa = prompt("Entert the number:");
    }
    
}