let shoppingList = ['dal','rice','sugar','teapowder','oliveoil'];
console.log(shoppingList);
let shoppingbasket = shoppingList;
shoppingbasket.push("chenna")
shoppingbasket.push("coffee")
console.log(shoppingbasket);
