var sales = prompt("Enter the amount: ");
if( sales > 0 && sales<= 5000){
    var s = (sales * 2)/100;
     var a = sales * 5/100;
    console.log("The reward is "+s);
    console.log("The rewar earned by him "+a);
}
else if(sales > 5001 && sales <= 10000){
    var sale = (sales * 5)/100;
     var sa = sales * 12/100;
    console.log("The reward is "+sale);
    console.log("The rewar earned by him "+sa);
}
else if(sales > 10001 && sales <= 20000){
    var sale = (sales * 7)/100;
     var sa = sales * 14/100;
    console.log("The reward is "+sale);
    console.log("The rewar earned by him "+sa);
}
else if(sales > 20001 ){
    var sales2 = (sales * 10)/100;
     var sales3 = sales * 20/100;
    console.log("The reward is "+sales2);
    console.log("The rewar earned by him "+sales3);
}
else{
}





