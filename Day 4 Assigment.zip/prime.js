var n =  prompt("Enter the n value:");
let num = 0;
let cnt = 0;
for (let i = 1; num< n; i++ )
{
   cnt = 0;
    for( let j = 1; j< i; j++){
        if(i%j == 0 ){
            cnt = cnt +1;
        }
    }
    if(cnt == 1){
        console.log(i);
        num = num +1;
    }
}