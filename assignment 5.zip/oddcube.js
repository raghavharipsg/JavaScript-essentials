let n = prompt("Enter the array size:");
let arr = [];
for (let i = 0; i < n; i++) {
    var val = 0;
    val = prompt("Enter the value: ")
        arr.push(val);
}
console.log(arr);
let odd = arr.filter(el=>el%2!=0);
let oddSquares = arr.filter(el=>el%2!=0).map(el=>el**3);

console.log(odd);
console.log(oddSquares);