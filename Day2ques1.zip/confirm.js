let val = confirm("Are you above the age 21?");
console.log(val)