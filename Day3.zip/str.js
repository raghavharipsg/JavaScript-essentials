//string
let txt = " hi gGhello Wwelcome to javascript.";
    console.log(txt.length);
    console.log(txt.substring(1,5));
    // Array
let arr = ["orange", "banana"];
let arr1 = ["lemon"];
console.log(arr.concat(arr1));
console.log(arr.length);
console.log(arr.pop);
console.log(arr);